"""Burt Lancaster's The Swimmer: a small Frogger-style Pygame game."""

from pathlib import Path
import asyncio
import math

import pygame


# Window and game settings
WIDTH, HEIGHT = 960, 720
FPS = 60
PLAYER_SIZE = (54, 110)
POOLS_TO_WIN = 5
ASSET_DIR = Path(__file__).parent / "assets"
SPRITE_DIR = ASSET_DIR / "sprites"
BACKGROUND_DIR = ASSET_DIR / "backgrounds"
POOL_GOAL = pygame.Rect(342, 128, 276, 38)

# A sunny, slightly faded 1960s palette
CREAM = (250, 238, 200)
DARK_GREEN = (29, 72, 61)
GRASS = (104, 170, 92)
GRASS_DARK = (83, 146, 78)
POOL_BLUE = (53, 181, 210)
POOL_LIGHT = (151, 235, 237)
DECK = (223, 196, 151)
BLACK = (30, 29, 28)
WHITE = (255, 255, 245)
RED = (196, 67, 45)
ORANGE = (219, 103, 53)
GOLD = (244, 194, 77)
INK = (18, 55, 49)


def load_burt():
    """Return separate game-size and full-resolution versions of Burt."""
    sprite_path = ASSET_DIR / "burt_sprite.png"
    try:
        source = pygame.image.load(str(sprite_path)).convert_alpha()
    except (pygame.error, FileNotFoundError):
        source = pygame.Surface(PLAYER_SIZE, pygame.SRCALPHA)
        pygame.draw.circle(source, (211, 142, 89), (27, 15), 12)
        pygame.draw.polygon(source, (211, 142, 89), [(14, 27), (40, 27), (45, 72), (9, 72)])
        pygame.draw.rect(source, BLACK, (13, 64, 28, 20))
        pygame.draw.line(source, (211, 142, 89), (18, 82), (15, 108), 8)
        pygame.draw.line(source, (211, 142, 89), (36, 82), (39, 108), 8)

    game_sprite = pygame.transform.scale(source, PLAYER_SIZE)
    return game_sprite, source


def load_obstacle_sprites():
    """Load the optional obstacle PNGs; procedural drawings remain as fallbacks."""
    filenames = {
        "cocktail": "cocktail_guest.png",
        "mower": "riding_mower.png",
        "poodle": "poodle.png",
        "dachshund": "dachshund.png",
        "beagle": "beagle.png",
        "horse": "horse.png",
        "grill": "kettle_grill.png",
    }
    sprites = {}
    for name, filename in filenames.items():
        try:
            sprites[name] = pygame.image.load(str(SPRITE_DIR / filename)).convert_alpha()
        except (pygame.error, FileNotFoundError):
            pass
    return sprites


def load_scene_backgrounds():
    """Load the five optional level panoramas in story order."""
    filenames = (
        "level_1_woodland.png",
        "level_2_biswanger.png",
        "level_3_road.png",
        "level_4_public_pool.png",
        "level_5_house.png",
    )
    backgrounds = []
    for filename in filenames:
        try:
            image = pygame.image.load(str(BACKGROUND_DIR / filename)).convert()
            backgrounds.append(pygame.transform.smoothscale(image, (WIDTH, 134)))
        except (pygame.error, FileNotFoundError):
            backgrounds.append(None)
    return backgrounds


def draw_text(surface, font, text, color, center):
    image = font.render(text, True, color)
    surface.blit(image, image.get_rect(center=center))


class Player:
    """The player-controlled Burt sprite."""

    def __init__(self, image):
        self.image_right = image
        self.image_left = pygame.transform.flip(image, True, False)
        self.facing_right = True
        self.position = pygame.Vector2(0, 0)
        self.animation_time = 0.0
        self.moving = False
        self.reset()

    def reset(self):
        self.position.update(WIDTH / 2 - PLAYER_SIZE[0] / 2, HEIGHT - PLAYER_SIZE[1] - 12)

    @property
    def hitbox(self):
        # Only Burt's lower body collides. This makes near misses feel fair.
        return pygame.Rect(
            round(self.position.x + 12),
            round(self.position.y + 50),
            PLAYER_SIZE[0] - 24,
            PLAYER_SIZE[1] - 54,
        )

    def update(self, keys, dt):
        direction = pygame.Vector2(0, 0)
        direction.x = keys[pygame.K_RIGHT] + keys[pygame.K_d] - keys[pygame.K_LEFT] - keys[pygame.K_a]
        direction.y = keys[pygame.K_DOWN] + keys[pygame.K_s] - keys[pygame.K_UP] - keys[pygame.K_w]

        self.moving = direction.length_squared() > 0
        if self.moving:
            direction = direction.normalize()
            self.position += direction * 235 * dt
            self.animation_time += dt
            if direction.x:
                self.facing_right = direction.x > 0

        self.position.x = max(8, min(WIDTH - PLAYER_SIZE[0] - 8, self.position.x))
        self.position.y = max(63, min(HEIGHT - PLAYER_SIZE[1] - 8, self.position.y))

    def draw(self, surface):
        bob = round(math.sin(self.animation_time * 15) * 2) if self.moving else 0
        feet_x = round(self.position.x + PLAYER_SIZE[0] / 2)
        feet_y = round(self.position.y + PLAYER_SIZE[1] - 3)
        pygame.draw.ellipse(surface, (51, 94, 62), (feet_x - 18, feet_y - 5, 36, 11))
        image = self.image_right if self.facing_right else self.image_left
        surface.blit(image, (round(self.position.x), round(self.position.y + bob)))


class Obstacle:
    """One suburban hazard moving across a lawn lane."""

    def __init__(self, kind, x, y, width, height, speed, variant="", unlock_score=0, image=None):
        self.kind = kind
        self.variant = variant
        self.unlock_score = unlock_score
        self.rect = pygame.Rect(x, y, width, height)
        self.x = float(x)
        self.speed = speed
        self.image = None
        if image is not None:
            self.image = pygame.transform.smoothscale(image, (width, height))
            if speed < 0:
                self.image = pygame.transform.flip(self.image, True, False)

    def update(self, dt, speed_multiplier):
        self.x += self.speed * speed_multiplier * dt
        margin = 100
        if self.speed > 0 and self.x > WIDTH + margin:
            self.x = -self.rect.width - margin
        elif self.speed < 0 and self.x + self.rect.width < -margin:
            self.x = WIDTH + margin
        self.rect.x = round(self.x)

    def draw(self, surface):
        x, y, w, h = self.rect
        pygame.draw.ellipse(surface, (55, 105, 66), (x, y + h - 8, w, 13))

        if self.image is not None:
            surface.blit(self.image, self.rect)
            return

        if self.kind == "mower":
            # A broad riding mower driven by a very respectable suburban square.
            pygame.draw.circle(surface, BLACK, (x + 20, y + h - 8), 11)
            pygame.draw.circle(surface, BLACK, (x + w - 19, y + h - 8), 13)
            pygame.draw.rect(surface, RED, (x + 5, y + h - 31, w - 10, 23), border_radius=5)
            pygame.draw.rect(surface, (225, 185, 54), (x + 9, y + h - 23, 45, 12), border_radius=3)
            pygame.draw.rect(surface, BLACK, (x + 62, y + 27, 25, 7), border_radius=2)
            pygame.draw.line(surface, BLACK, (x + 45, y + 31), (x + 31, y + 20), 3)
            pygame.draw.circle(surface, BLACK, (x + 29, y + 19), 7, 2)

            shirt = (92, 141, 176) if self.variant == "blue" else (232, 219, 176)
            pygame.draw.rect(surface, shirt, (x + 57, y + 16, 24, 29), border_radius=5)
            pygame.draw.circle(surface, (218, 161, 111), (x + 68, y + 10), 10)
            pygame.draw.arc(surface, (92, 67, 49), (x + 57, y - 1, 22, 15), 0, math.pi, 5)
            pygame.draw.line(surface, BLACK, (x + 58, y + 10), (x + 66, y + 10), 2)
            pygame.draw.line(surface, BLACK, (x + 69, y + 10), (x + 77, y + 10), 2)
            pygame.draw.line(surface, BLACK, (x + 66, y + 10), (x + 69, y + 10), 1)
            pygame.draw.line(surface, (218, 161, 111), (x + 58, y + 26), (x + 34, y + 21), 5)
        elif self.kind == "dog":
            if self.variant == "poodle":
                fur = (239, 235, 218)
                pygame.draw.ellipse(surface, fur, (x + 19, y + 17, 33, 19))
                pygame.draw.circle(surface, fur, (x + 55, y + 15), 12)
                pygame.draw.circle(surface, fur, (x + 60, y + 5), 8)
                pygame.draw.circle(surface, fur, (x + 12, y + 14), 7)
                pygame.draw.line(surface, fur, (x + 26, y + 31), (x + 24, y + h), 5)
                pygame.draw.line(surface, fur, (x + 46, y + 31), (x + 48, y + h), 5)
                pygame.draw.circle(surface, fur, (x + 24, y + h - 1), 6)
                pygame.draw.circle(surface, fur, (x + 48, y + h - 1), 6)
                pygame.draw.line(surface, fur, (x + 19, y + 21), (x + 5, y + 8), 3)
                pygame.draw.circle(surface, BLACK, (x + 62, y + 13), 2)
            elif self.variant == "dachshund":
                brown = (139, 73, 39)
                pygame.draw.ellipse(surface, brown, (x + 9, y + 10, w - 31, 18))
                pygame.draw.circle(surface, brown, (x + w - 17, y + 13), 11)
                pygame.draw.ellipse(surface, (91, 48, 34), (x + w - 22, y + 14, 8, 16))
                pygame.draw.line(surface, brown, (x + 18, y + 25), (x + 17, y + h), 4)
                pygame.draw.line(surface, brown, (x + w - 34, y + 25), (x + w - 33, y + h), 4)
                pygame.draw.line(surface, brown, (x + 10, y + 14), (x - 3, y + 4), 3)
                pygame.draw.circle(surface, BLACK, (x + w - 12, y + 11), 2)
            else:  # beagle
                fur = (240, 225, 187)
                brown = (145, 81, 45)
                pygame.draw.ellipse(surface, fur, (x + 8, y + 13, w - 27, h - 20))
                pygame.draw.ellipse(surface, brown, (x + 27, y + 13, 24, h - 20))
                pygame.draw.circle(surface, brown, (x + w - 16, y + 14), 12)
                pygame.draw.ellipse(surface, (83, 52, 38), (x + w - 22, y + 15, 9, 18))
                pygame.draw.line(surface, fur, (x + 18, y + h - 13), (x + 17, y + h), 5)
                pygame.draw.line(surface, fur, (x + 45, y + h - 13), (x + 47, y + h), 5)
                pygame.draw.line(surface, fur, (x + 9, y + 17), (x - 3, y + 4), 4)
                pygame.draw.circle(surface, BLACK, (x + w - 11, y + 12), 2)
        elif self.kind == "horse":
            brown = (83, 55, 42)
            pygame.draw.ellipse(surface, brown, (x + 18, y + 16, 75, 32))
            pygame.draw.polygon(surface, brown, [(x + 81, y + 21), (x + 99, y + 2), (x + 108, y + 12), (x + 96, y + 38)])
            pygame.draw.ellipse(surface, brown, (x + 96, y + 3, 27, 18))
            pygame.draw.polygon(surface, BLACK, [(x + 102, y + 4), (x + 105, y - 5), (x + 110, y + 5)])
            pygame.draw.polygon(surface, BLACK, [(x + 115, y + 5), (x + 120, y - 3), (x + 121, y + 8)])
            pygame.draw.line(surface, BLACK, (x + 22, y + 19), (x + 1, y + 4), 6)
            for leg_x, foot_x in ((x + 30, x + 25), (x + 49, x + 53), (x + 75, x + 70), (x + 87, x + 93)):
                pygame.draw.line(surface, brown, (leg_x, y + 42), (foot_x, y + h), 7)
            pygame.draw.circle(surface, BLACK, (x + 117, y + 10), 2)
        elif self.kind == "grill":
            silver = (190, 194, 183)
            pygame.draw.circle(surface, BLACK, (x + 17, y + h - 4), 7)
            pygame.draw.circle(surface, BLACK, (x + w - 16, y + h - 4), 7)
            pygame.draw.line(surface, silver, (x + 20, y + 34), (x + 18, y + h - 6), 4)
            pygame.draw.line(surface, silver, (x + w - 21, y + 34), (x + w - 17, y + h - 6), 4)
            pygame.draw.line(surface, silver, (x + w // 2, y + 35), (x + w // 2, y + h - 1), 3)
            pygame.draw.ellipse(surface, RED, (x + 5, y + 12, w - 10, 36))
            pygame.draw.line(surface, (111, 31, 30), (x + 7, y + 31), (x + w - 7, y + 31), 3)
            pygame.draw.arc(surface, RED, (x + 7, y - 3, w - 14, 34), 0, math.pi, 11)
            pygame.draw.rect(surface, BLACK, (x + w // 2 - 8, y + 1, 16, 5), border_radius=2)
            pygame.draw.circle(surface, silver, (x + w // 2 + 13, y + 14), 5)
            pygame.draw.circle(surface, WHITE, (x + 20, y + 19), 5)
        else:  # a party guest carrying the cocktail tray
            skin = (211, 151, 103)
            silver = (205, 211, 205)
            dress = (145, 177, 64) if self.variant == "lime" else RED
            pygame.draw.line(surface, skin, (x + 35, y + 55), (x + 31, y + h - 3), 6)
            pygame.draw.line(surface, skin, (x + 49, y + 55), (x + 55, y + h - 3), 6)
            pygame.draw.line(surface, BLACK, (x + 25, y + h - 2), (x + 34, y + h - 2), 4)
            pygame.draw.line(surface, BLACK, (x + 53, y + h - 2), (x + 63, y + h - 2), 4)
            pygame.draw.polygon(surface, dress, [(x + 27, y + 22), (x + 53, y + 22), (x + 60, y + 57), (x + 20, y + 57)])
            pygame.draw.polygon(surface, WHITE, [(x + 27, y + 22), (x + 39, y + 22), (x + 35, y + 57), (x + 20, y + 57)])
            pygame.draw.circle(surface, skin, (x + 40, y + 12), 10)
            pygame.draw.arc(surface, (104, 62, 40), (x + 29, y + 1, 23, 19), 0, math.pi, 7)
            pygame.draw.line(surface, skin, (x + 52, y + 27), (x + 70, y + 31), 5)
            pygame.draw.line(surface, silver, (x + 65, y + 29), (x + w - 2, y + 29), 3)
            for glass_x in (x + 72, x + 84):
                pygame.draw.polygon(surface, POOL_LIGHT, [(glass_x - 4, y + 16), (glass_x + 4, y + 16), (glass_x + 2, y + 25), (glass_x - 2, y + 25)], 2)
                pygame.draw.line(surface, silver, (glass_x, y + 25), (glass_x, y + 29), 1)


def make_obstacles(sprites=None):
    sprites = sprites or {}
    return [
        Obstacle("cocktail", -30, 482, 48, 80, 110, "lime", image=sprites.get("cocktail")),
        Obstacle("cocktail", 465, 482, 48, 80, 110, "lime", image=sprites.get("cocktail")),
        Obstacle("mower", 170, 389, 92, 80, -116, "blue", image=sprites.get("mower")),
        Obstacle("mower", 710, 389, 92, 80, -116, "cream", image=sprites.get("mower")),
        Obstacle("dog", -60, 312, 65, 54, 157, "poodle", image=sprites.get("poodle")),
        Obstacle("dog", 330, 328, 82, 38, 157, "dachshund", image=sprites.get("dachshund")),
        Obstacle("dog", 735, 318, 76, 48, 157, "beagle", image=sprites.get("beagle")),
        Obstacle("horse", -650, 296, 112, 74, 125, unlock_score=2, image=sprites.get("horse")),
        Obstacle("grill", 155, 207, 46, 76, -102, image=sprites.get("grill")),
        Obstacle("grill", 670, 207, 46, 76, -102, image=sprites.get("grill")),
    ]


def draw_hot_dog_wagon(surface, font):
    """A small nod to Henry's wagon from the pool-party sequence."""
    x, y = 23, 91
    pygame.draw.circle(surface, (111, 38, 34), (x + 29, y + 66), 15)
    pygame.draw.circle(surface, (111, 38, 34), (x + 133, y + 66), 15)
    pygame.draw.circle(surface, DECK, (x + 29, y + 66), 8)
    pygame.draw.circle(surface, DECK, (x + 133, y + 66), 8)
    pygame.draw.rect(surface, CREAM, (x + 15, y + 21, 132, 43))
    pygame.draw.rect(surface, RED, (x + 15, y + 21, 132, 43), 3)
    pygame.draw.rect(surface, RED, (x + 9, y + 7, 144, 19), border_radius=3)
    label = font.render("HENRY'S", True, CREAM)
    surface.blit(label, label.get_rect(center=(x + 81, y + 16)))
    pygame.draw.rect(surface, RED, (x + 23, y + 31, 44, 23), 2)
    pygame.draw.rect(surface, RED, (x + 94, y + 31, 44, 23), 2)
    pygame.draw.line(surface, RED, (x + 81, y + 25), (x + 81, y + 63), 3)
    pygame.draw.line(surface, BLACK, (x + 65, y + 66), (x + 65, y + 83), 3)


def draw_greenhouse_party(surface):
    """Film-specific scenery outside the playable pool opening."""
    frame = (39, 91, 70)
    glass = (177, 220, 197)
    greenhouse = pygame.Rect(774, 85, 163, 84)
    pygame.draw.rect(surface, glass, greenhouse)
    pygame.draw.rect(surface, frame, greenhouse, 3)
    pygame.draw.arc(surface, frame, (774, 61, 163, 67), 0, math.pi, 4)
    for x in range(795, 938, 29):
        pygame.draw.line(surface, frame, (x, 86), (x, 168), 2)
        pygame.draw.line(surface, frame, (x, 86), (855, 63), 1)

    def guest(center_x, base_y, color, jacket=False):
        skin = (210, 151, 103)
        pygame.draw.circle(surface, skin, (center_x, base_y - 35), 6)
        if jacket:
            pygame.draw.rect(surface, color, (center_x - 7, base_y - 29, 14, 20))
            pygame.draw.line(surface, CREAM, (center_x, base_y - 28), (center_x, base_y - 10), 2)
        else:
            pygame.draw.polygon(surface, color, [(center_x - 7, base_y - 29), (center_x + 7, base_y - 29), (center_x + 10, base_y - 8), (center_x - 10, base_y - 8)])
        pygame.draw.line(surface, BLACK, (center_x - 4, base_y - 8), (center_x - 5, base_y), 2)
        pygame.draw.line(surface, BLACK, (center_x + 4, base_y - 8), (center_x + 5, base_y), 2)

    guest(188, 176, (237, 186, 70), True)
    guest(756, 176, RED)
    guest(912, 176, (142, 178, 73))


def draw_yard(surface, small_font, elapsed, level=0, backgrounds=None):
    surface.fill(GRASS)
    pygame.draw.rect(surface, DARK_GREEN, (0, 0, WIDTH, 64))

    # The scene art lives only in this protected strip. The four crossing
    # lanes remain simple and high-contrast, so decoration never muddies play.
    scene = None
    if backgrounds:
        scene = backgrounds[max(0, min(level, len(backgrounds) - 1))]
    if scene is not None:
        surface.blit(scene, (0, 64))

    # Alternating lanes make the crossing route immediately readable.
    for y in (198, 382):
        pygame.draw.rect(surface, GRASS_DARK, (0, y, WIDTH, 92))
    for y in (290, 474):
        pygame.draw.rect(surface, GRASS, (0, y, WIDTH, 92))

    # A smaller shallow-perspective pool leaves room for the scene behind it.
    deck_points = ((315, 108), (645, 108), (683, 185), (277, 185))
    water_points = ((330, 120), (630, 120), (655, 170), (305, 170))
    pygame.draw.polygon(surface, DECK, deck_points)
    pygame.draw.lines(surface, (185, 151, 105), True, deck_points, 3)
    pygame.draw.polygon(surface, POOL_BLUE, water_points)

    # Draw ripples on a separate layer, then mask them to the water polygon.
    # This guarantees that animation never spills over the coping.
    wave_layer = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    wave_shift = int(elapsed * 28) % 62
    for row_y, left, right, phase in ((127, 328, 632, 0), (148, 316, 644, 31)):
        for x in range(left - 62 + wave_shift + phase, right, 62):
            pygame.draw.arc(wave_layer, POOL_LIGHT, (x, row_y, 35, 13), 0, math.pi, 2)
    water_mask = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    pygame.draw.polygon(water_mask, WHITE, water_points)
    wave_layer.blit(water_mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    surface.blit(wave_layer, (0, 0))
    pygame.draw.lines(surface, WHITE, True, water_points, 3)
    pygame.draw.line(surface, (180, 142, 98), deck_points[3], deck_points[2], 4)

    if scene is None:
        # Procedural scenery remains as a graceful fallback if assets are moved.
        for x in range(0, 200, 34):
            pygame.draw.circle(surface, (38, 105, 64), (x, 165), 26)
        for x in range(760, WIDTH + 30, 34):
            pygame.draw.circle(surface, (38, 105, 64), (x, 165), 26)
        draw_hot_dog_wagon(surface, small_font)
        draw_greenhouse_party(surface)
    else:
        # A narrow clipped hedge finishes the scene without hiding its landmarks.
        pygame.draw.rect(surface, (35, 91, 54), (0, 188, WIDTH, 10))
        for x in (*range(0, 200, 28), *range(760, WIDTH + 28, 28)):
            pygame.draw.circle(surface, (38, 105, 64), (x, 190), 10)

    labels = [(244, "BARBECUE"), (343, "DOGS & PADDOCK"), (434, "MOWING DAY"), (526, "COCKTAIL HOUR")]
    for y, text in labels:
        label = small_font.render(text, True, (43, 102, 61))
        surface.blit(label, (12, y))

    # Small flowers add charm without requiring more image assets.
    for x in range(35, WIDTH, 92):
        pygame.draw.circle(surface, (255, 214, 89), (x, 596), 5)
        pygame.draw.circle(surface, WHITE, (x + 5, 596), 5)
        pygame.draw.line(surface, DARK_GREEN, (x + 2, 600), (x + 2, 611), 2)

    return POOL_GOAL


def draw_hud(surface, font, score, lives):
    title = font.render("BURT LANCASTER'S  THE SWIMMER", True, CREAM)
    surface.blit(title, (18, 17))
    status = font.render(f"POOLS {score}/{POOLS_TO_WIN}     LIVES {lives}", True, WHITE)
    surface.blit(status, status.get_rect(topright=(WIDTH - 18, 17)))


def draw_gold_title(surface, font, text, position):
    """Draw readable flat gold lettering with a restrained one-pixel edge."""
    x, y = position
    edge = font.render(text, True, (79, 49, 22))
    gold = font.render(text, True, (205, 143, 39))
    for offset_x, offset_y in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        surface.blit(edge, (x + offset_x, y + offset_y))
    surface.blit(gold, (x, y))


def draw_poster_menu(surface, fonts, poster_burt, mode, score, elapsed):
    """Draw a clean, 1960s-inspired movie-poster menu."""
    surface.fill(INK)
    left_panel = pygame.Rect(18, 18, 570, 684)
    right_panel = pygame.Rect(588, 18, 354, 684)
    pygame.draw.rect(surface, CREAM, left_panel)
    pygame.draw.rect(surface, POOL_BLUE, right_panel)

    # Graphic pool lines and a warm sun give the poster a period look.
    pygame.draw.circle(surface, ORANGE, (765, 211), 147)
    for y in (385, 445, 505, 565):
        pygame.draw.line(surface, POOL_LIGHT, (612, y), (918, y), 3)
        for x in range(622, 920, 73):
            pygame.draw.arc(surface, CREAM, (x, y - 12, 42, 22), 0, math.pi, 2)
    pygame.draw.rect(surface, DARK_GREEN, (588, 632, 354, 70))

    # Use the full-resolution source here, never the tiny gameplay sprite.
    poster_height = 603
    poster_width = round(poster_burt.get_width() * poster_height / poster_burt.get_height())
    large_burt = pygame.transform.smoothscale(poster_burt, (poster_width, poster_height))
    surface.blit(large_burt, large_burt.get_rect(midbottom=(766, 703)))

    x = 62
    if mode == "title":
        eyebrow = "BURT LANCASTER IN"
        title_lines = ("THE", "SWIMMER")
        tagline = ("Across the lawns. Through the parties.", "Into the pool.")
        label = "THE OBJECTIVE"
        details = ("Cross four suburban lanes.", "Reach five backyard pools.")
        button = "PRESS ENTER TO SWIM"
        footer = "ARROW KEYS / WASD TO MOVE     •     ESC TO QUIT"
    elif mode == "won":
        eyebrow = "A MAGNIFICENT FINISH"
        title_lines = ("BURT MADE", "IT HOME!")
        tagline = ("Five pools. One magnificent swim.", "The Lucinda River is complete.")
        label = "FINAL SCORE"
        details = (f"Pools reached: {score} of {POOLS_TO_WIN}.", "No robe required.")
        button = "PRESS ENTER TO SWIM AGAIN"
        footer = "R OR ENTER TO RESTART     •     ESC TO QUIT"
    else:
        eyebrow = "THE JOURNEY PAUSES"
        title_lines = ("THE SWIM", "ENDS HERE")
        tagline = ("The suburbs have had their say.", "Burt can always begin again.")
        label = "THIS ATTEMPT"
        details = (f"Pools reached: {score} of {POOLS_TO_WIN}.", "Three setbacks ended the swim.")
        button = "PRESS ENTER TO TRY AGAIN"
        footer = "R OR ENTER TO RESTART     •     ESC TO QUIT"

    surface.blit(fonts["eyebrow"].render(eyebrow, True, ORANGE), (x, 58))
    if mode == "title":
        swimmer_width = fonts["title_large"].size("SWIMMER")[0]
        the_width = fonts["title_small"].size("THE")[0]
        the_x = x + (swimmer_width - the_width) // 2
        draw_gold_title(surface, fonts["title_small"], "THE", (the_x, 96))
        draw_gold_title(surface, fonts["title_large"], "SWIMMER", (x, 145))
    else:
        for line, line_y in zip(title_lines, (100, 178)):
            draw_gold_title(surface, fonts["title"], line, (x, line_y))

    surface.blit(fonts["tagline"].render(tagline[0], True, BLACK), (x, 287))
    surface.blit(fonts["tagline"].render(tagline[1], True, BLACK), (x, 320))
    pygame.draw.line(surface, ORANGE, (x, 374), (535, 374), 5)

    surface.blit(fonts["eyebrow"].render(label, True, ORANGE), (x, 401))
    surface.blit(fonts["body"].render(details[0], True, INK), (x, 440))
    surface.blit(fonts["body"].render(details[1], True, INK), (x, 470))

    button_rect = pygame.Rect(x, 526, 474, 64)
    pulse = 3 + round((math.sin(elapsed * 4) + 1) * 1.5)
    pygame.draw.rect(surface, ORANGE, button_rect, border_radius=4)
    pygame.draw.rect(surface, GOLD, button_rect, pulse, border_radius=4)
    draw_text(surface, fonts["button"], button, WHITE, button_rect.center)

    surface.blit(fonts["small"].render(footer, True, INK), (x, 625))
    surface.blit(fonts["credits"].render("A SUBURBAN CROSSING GAME", True, INK), (x, 667))
    draw_text(surface, fonts["credits"], "A PYGAME EXTRA-CREDIT PICTURE", CREAM, (765, 43))

    pygame.draw.rect(surface, CREAM, (8, 8, WIDTH - 16, HEIGHT - 16), 6)


def make_poster_fonts():
    return {
        "eyebrow": pygame.font.SysFont("arial,helvetica", 22, bold=True),
        "title": pygame.font.SysFont("georgia,timesnewroman,times", 64, bold=True),
        "title_small": pygame.font.SysFont("georgia,timesnewroman,times", 48, bold=True),
        "title_large": pygame.font.SysFont("georgia,timesnewroman,times", 75, bold=True),
        "tagline": pygame.font.SysFont("georgia,timesnewroman,times", 25, italic=True),
        "body": pygame.font.SysFont("arial,helvetica", 23),
        "button": pygame.font.SysFont("arial,helvetica", 21, bold=True),
        "small": pygame.font.SysFont("arial,helvetica", 15, bold=True),
        "credits": pygame.font.SysFont("arial,helvetica", 13, bold=True),
    }


async def main():
    pygame.init()
    pygame.display.set_caption("Burt Lancaster's The Swimmer")
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()
    hud_font = pygame.font.Font(None, 30)
    small_font = pygame.font.Font(None, 20)
    body_font = pygame.font.Font(None, 32)

    poster_fonts = make_poster_fonts()

    burt_image, poster_burt = load_burt()
    obstacle_sprites = load_obstacle_sprites()
    scene_backgrounds = load_scene_backgrounds()
    player = Player(burt_image)
    obstacles = make_obstacles(obstacle_sprites)
    state = "title"
    score = 0
    lives = 3
    message = ""
    message_timer = 0.0
    elapsed = 0.0
    pool_messages = [
        "Another pool conquered!",
        "The Lucinda River continues!",
        "Surely home is just ahead.",
        "Burt remains magnificent.",
        "The long swim is complete!",
    ]

    def start_game():
        nonlocal state, score, lives, obstacles, message_timer
        state = "playing"
        score = 0
        lives = 3
        obstacles = make_obstacles(obstacle_sprites)
        message_timer = 0.0
        player.reset()

    running = True
    while running:
        dt = min(clock.tick(FPS) / 1000, 0.05)
        elapsed += dt

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif state == "title" and event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    start_game()
                elif state in ("game_over", "won") and event.key in (pygame.K_r, pygame.K_RETURN):
                    start_game()

        if state == "playing":
            speed_multiplier = 1.0 + score * 0.12
            active_obstacles = [obstacle for obstacle in obstacles if score >= obstacle.unlock_score]
            for obstacle in active_obstacles:
                obstacle.update(dt, speed_multiplier)

            if message_timer > 0:
                message_timer -= dt
            else:
                player.update(pygame.key.get_pressed(), dt)

                if any(player.hitbox.colliderect(obstacle.rect) for obstacle in active_obstacles):
                    lives -= 1
                    player.reset()
                    message = "A suburban setback!"
                    message_timer = 1.0
                    if lives == 0:
                        state = "game_over"

                elif POOL_GOAL.collidepoint(player.hitbox.center):
                    score += 1
                    message = pool_messages[score - 1]
                    message_timer = 1.15
                    player.reset()
                    if score == POOLS_TO_WIN:
                        state = "won"

        if state == "playing":
            draw_yard(screen, small_font, elapsed, score, scene_backgrounds)
            for obstacle in active_obstacles:
                obstacle.draw(screen)
            player.draw(screen)
            draw_hud(screen, hud_font, score, lives)
            if message_timer > 0:
                banner = pygame.Rect(265, 622, 430, 54)
                pygame.draw.rect(screen, CREAM, banner, border_radius=12)
                pygame.draw.rect(screen, DARK_GREEN, banner, 3, border_radius=12)
                draw_text(screen, body_font, message, DARK_GREEN, banner.center)
        else:
            draw_poster_menu(screen, poster_fonts, poster_burt, state, score, elapsed)

        pygame.display.flip()
        # Yield once per frame so the browser can process input and repaint.
        await asyncio.sleep(0)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
